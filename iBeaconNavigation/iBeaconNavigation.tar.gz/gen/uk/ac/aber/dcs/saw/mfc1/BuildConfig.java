/** Automatically generated file. DO NOT MODIFY */
package uk.ac.aber.dcs.saw.mfc1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}