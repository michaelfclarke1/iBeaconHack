package uk.ac.aber.dcs.saw.mfc1.nav;

public enum FriendlyNav {

	N, NNE, NE, ENE, E, ESE, SE, SSE, S, SSW, SW, WSW, W, WNW, NW, NNW, UPSTAIRS, DOWNSTAIRS
	 
	
}
